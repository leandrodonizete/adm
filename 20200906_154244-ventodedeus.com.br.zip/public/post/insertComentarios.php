
<?php

$host = "mysql669.umbler.com:41890";
$db   = "ventodedeus";
$user = "leandrodomingues";
$pass = "a36825700";

//$dat= "new Date()";

$connection=mysqli_connect($host, $user, $pass, $db);
if (mysqli_connect_errno())
  {
  echo "Falha ao conectar ao MySQL: " . mysqli_connect_error();
  
  //idDoPost, autorComentario, idcomentarios, textocoment 
  }
//idDoPost, autor, id, dataDoComentario, comentario, 
$sql="INSERT INTO Comentarios (id, idDoPost, autor, dataDoComentario, comentario)
VALUES  
('$_POST[idcomentarios]','$_POST[idDoPost]','$_POST[autorComentario]','$_POST[dataDoComentario]','$_POST[textocoment]')";
//A instrução POST recupera os dados do formulário.
if (!mysqli_query($connection,$sql))
  {
  die('Erro: ' . mysqli_error($connection));
  }
  
else
echo "<script>window.close()</script>";
 
mysqli_close($connection);
//Este comando fecha a conexão ao banco de dados ao final.
?>