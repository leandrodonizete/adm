<?php


    session_start();
    
    
include ('conectaPost.php');

?>
     <?php
   $ctd_id1 = $_SESSION['curtidab'];
  $ctd3 = $_SESSION['curtidaa'];
  
if ($_SESSION[$ctd_id1] != 'curtidas') { 
     $_SESSION[$ctd_id1 + 'a'] = $ctd3 + 1;
    $_SESSION[$ctd_id1] = 'curtidas';
$ctd2 =  $_SESSION[$ctd_id1 + 'a'];
 mysql_query("UPDATE Post SET  curtidas='$ctd2'  WHERE id='$ctd_id1'");
 	echo "<script>window.close()</script>";
 	
?>
<?php } 
elseif ($_SESSION[$ctd_id1] == 'curtidas') { 
     $_SESSION[$ctd_id1 + 'a'] = $ctd3 - 1;
    $_SESSION[$ctd_id1] = 'curtida';
$ctd2 =  $_SESSION[$ctd_id1 + 'a'];
 mysql_query("UPDATE Post SET  curtidas='$ctd2'  WHERE id='$ctd_id1'");
 	echo "<script>window.close()</script>";
 	
?>


<?php } 

else {
?>

 <?php
 
echo "<script>window.close()</script>";
 	} ?>
 


