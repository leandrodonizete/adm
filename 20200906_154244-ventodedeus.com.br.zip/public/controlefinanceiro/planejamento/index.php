<!DOCTYPE html>
<html>
    
<?
include('conexao.php');

?>
<head>

		<title>
...
		</title>
</head>
<body>
   		
<script type="text/javascript">
function id(el) {
  return document.getElementById( el );
}
function total( un, qnt ) {
  return parseFloat(un.replace(',', '.'), 10) * parseFloat(qnt.replace(',', '.'), 10);
}
window.onload = function() {
 //    var result = total(  id('valor_unitario').value , id('qnt').value );
   // id('total').value ="R$ " + String(result.toFixed(2)).formatMoney();
  
  id('valor_unitario').addEventListener('keyup', function() {
    var result = total( this.value , id('qnt').value );
    id('total').value ="R$ " + String(result.toFixed(2)).formatMoney();
  });

  id('qnt').addEventListener('keyup', function(){
    var result = total( id('valor_unitario').value , this.value );
    id('total').value ="R$ " + String(result.toFixed(2)).formatMoney();
  });
}

String.prototype.formatMoney = function() {
  var v = this;

  if(v.indexOf('.') === -1) {
    v = v.replace(/([\d]+)/, "$1,00");
  }

  v = v.replace(/([\d]+)\.([\d]{1})$/, "$1,$20");
  v = v.replace(/([\d]+)\.([\d]{2})$/, "$1,$2");
  v = v.replace(/([\d]+)([\d]{3}),([\d]{2})$/, "$1.$2,$3");

  return v;
};
</script>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<?php 
// where titulo = '".$_GET["titulo"]."' "
$sql="SELECT * from ControleFinanceiro";
$rs=mysql_query($sql,$conn) or die(mysql_error());
$result=mysql_fetch_array($rs);
$total = mysql_num_rows($rs);     
	//	$resultado = $result["quantidade"];
 //   $subtotal = sum(valor);
          //---------------------------
if($total > 0) {
		// inicia o loop que vai mostrar todos os dados
		do {
		    
		    //	for($i = 1; $i <= 1; $i++)
                  {
      
      
  echo ' <table id="tblEditavel" class="table table-condensed table-striped table-hover">
  <caption>Lançamento </caption>
  <thead>
    <tr>
      <th>#</th>
      <th>Nome</th>
      <th>Número</th>
      <th>Parcela</th>
      <th>Vencimento</th>
      <th>Valor</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>88</td>
      <td>'.$result["quantidade"].'</td>
      <td>99</td>
      <td>1 <b>de</b> 4<b style="color: red;"> </b></td>
      <td title="Vencimento" class="editavel dt">21/10/2017</td>
      <td id="a1" title="Valor" class="vlr">R$ 375,37</td>
    </tr>   
   <tr>
      <td colspan="4"><b>Total</b></td>
      <td style="text-align: right"><b><span id="valor_total" style="color: blue;"></span></b></td>
      <td><b><span id="valor_total_insert">R$1.501,42</span></b></td>
    </tr>
  </tbody>
</table> '
   
?>

<?php
// finaliza o loop que vai mostrar os dados
		}while( $result = mysql_fetch_assoc($rs));
	// fim do if
	}
}
	?>
	<div id="qtdtotal">
    </div>




<script>
  $(function(){

    var editavelvlr = 0;

    $( ".editavelvlr" ).each(function() {
      editavelvlr += parseInt($( this ).text());
    });
     $( "#qtdtotal" ).text(editavelvlr);
    
  
      
  });
</script>
</body>




</html>