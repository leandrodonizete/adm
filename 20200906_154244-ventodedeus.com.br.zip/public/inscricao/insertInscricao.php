
<?php

$host = "mysql669.umbler.com:41890";
$db   = "ventodedeus";
$user = "leandrodomingues";
$pass = "a36825700";

//$dat= "new Date()";
$senhacrypto1 = $_POST[senha];

$senhacrypto = md5($senhacrypto1);
$connection=mysqli_connect($host, $user, $pass, $db);

if (mysqli_connect_errno())
  {
  echo "Falha ao conectar ao MySQL: " . mysqli_connect_error();
  }
$sql="INSERT INTO usuarios (email, nome, senha, situacoe_id, niveis_acesso_id, id,created )
VALUES
('$_POST[email]','$_POST[nome]','$senhacrypto','$_POST[situacoe_id]','$_POST[niveis_acesso_id]','$_POST[id]','$_POST[created]')";
//A instrução POST recupera os dados do formulário.
if (!mysqli_query($connection,$sql))
  {
  die('Erro: ' . mysqli_error($connection));
  }
  
else
echo "1 registro inserido.     ";
 
mysqli_close($connection);
//Este comando fecha a conexão ao banco de dados ao final.
?>