<?
echo "<script>window.close()</script>";
?>