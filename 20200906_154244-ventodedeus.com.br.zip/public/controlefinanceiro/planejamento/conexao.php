
<?php
$conn=mysql_connect("mysql669.umbler.com:41890","leandrodomingues","a36825700");
mysql_select_db("ventodedeus",$conn);
?>