<!DOCTYPE html>
<html>
    
<?  
//session_destroy();
session_start();
//insertVisualizacao.php
//$_SESSION['visualizacao'] = '55';
include ('conectaPost.php');

?>

   	<head>
	
  <script src="https://code.jquery.com/jquery-3.5.0.js"></script>

	
<script
  src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
	
<link rel="49d33f_0499eef5ff18438592f4543cca97352f~mv2 icon" href="https://static.wixstatic.com/media/49d33f_0499eef5ff18438592f4543cca97352f~mv2.png" >

<link href='https://fonts.googleapis.com/css?family=Anton' rel='stylesheet'>

<meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" media="screen" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" />
    <link rel="stylesheet" type="text/css" media="screen" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" />
  
    <meta charset="utf-8"/>


		<title>
Post
		</title>
		
<style>


	.tw-heart-box {
  position: relative;
  width: 100px;
  height: 100px;
  display: inline-block;
}

.field{
    margin-left:1%;
    width: 60%;
    margin: 15px 0;
}

.tw-heart {
  background: url(http://i.imgur.com/zw8ahUb.png) no-repeat 0 0;
  display: inline-block;
  width: inherit;
  height: inherit;
  position: absolute;
  left: 0;
  top: 0;
}

[type="checkbox"]:checked + .tw-heart {
  transition: background .8s steps(28);
  background-position: -2800px 0;
}

[type="checkbox"] {
  opacity: 0;
  cursor: pointer;
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  z-index: 1;
}
    
input[type=text],
input[type=email],
input[type=password],
textarea{
    width: 100%;
    padding-left: 10px;
    height: 30px;
    line-height: 30px;
    border-radius: 15px;
    border: 1px solid #ccc;
    outline: none;
}
.hs51 { 

    font-family: 'Anton';
	font-size: 22px;
	color:#FF7700;
	position: absolute;
	text-decoration: underline;
	 top: -15px;
   left: center;
   
} 

.hs52 {
    font-family: 'Anton';
	font-size: 28px;
	color: #CCCCCC;
	position: absolute;
   top: 20px;
   left: 65px;
}

.hs53 {

width: 100%
	position: absolute;
   top: 14px;
   left: 130px;
}

.h3 { 
font-family: Anton; 
font-size: 14px; 
font-style: normal; 
font-variant: normal; 
font-weight: 700; 
line-height: 15.4px; } 
color:FF7700;
.p { 
font-family: Anton; 
font-size: 14px; 
font-style: normal; 
font-variant: normal; 
font-weight: 400; 
line-height: 20px; } 

.blockquote { 
font-family: Anton; 
font-size: 21px; 
font-style: normal; 
font-variant: normal; 
font-weight: 400; 
line-height: 30px; 
} 
.pre { 
font-family: Anton; 
font-size: 13px; 
font-style: normal; 
font-variant: normal; 
font-weight: 400; 
line-height: 18.5714px; }


#esquerda3400 {


	width: 111px;
	position: fixed;
	left: 90%;
	margin-top:-100px;
	}

.circulo{
border-radius:50%;
-moz-border-radius:50%;
-webkit-border-radius:50%;

background:#FF5500;
color:white;
width:111px;
height:111px;
line-height:100px;
vertical-align:middle;
text-align:center;
font-size:30px;


}

body {
            background-color: black;
        }
.hra{
  border-color:#FF7700;

  box-sizing:border-box;
  width:100%;

  border-bottom: 5px solid #FF7700;
}
.hrb{
  border-color:#cccccc;

  box-sizing:border-box;
  width:100%;

  border-bottom: 5px solid #cccccc;
}
.Menu {
right:20%;
	position: absolute;
   top: 25px;
   
     background-color: black;
     border: 1px solid #FF7700;
   }
#botoesMenu {
	
	visibility: hidden;
	
   
   }
.botao {

	font-weight: bold;
	margin-left: 02px;
	font-family: Nimbus Sans;
    background-color: transparent;
    outline: 0;
    text-align: left;
    border-radius: 10px;
	border: 0px;
   font-size: 13pt;
   margin: 2px;
   color: white;
}

.botao:hover {
  color: white;
  background-color:#FF5500;
  transition: color 0.2s 0.10s ease;
  transition: background-color 0.2s 0.05s ease;
  cursor: pointer;
  
  }
  
  
.jsjpfylp {
	background-color: #FF7700;
}
.postagem {
   


min-width: 300px;	
width: 75%;
	left: center;
    
    background-color: #2F2E2E;
    box-shadow: 0 0 08px;
    margin: 10px;
	

}
.textoPostagem {

	width:90%;
	left: center;
    height: 9%;
    background-color: white;
    box-shadow: 0 0 08px;
    margin: 10px;
}


span {
    display: none;
}

</style>
</head>

<body>


<!-- MENU -->

<hr/ class= "hrb" style= "margin-top: 2px;">
<hr/ class= "hra" style= "margin-top: -16px;">
	
	<div>
			<div class="hs53">
				<img style="margin-top:-1%;" width="270px" src="https://static.wixstatic.com/media/49d33f_1b99852a9f63498084abf3dba864f78a~mv2.jpg">
						<!-- Logo -->
						<div class="hs52">
									<img width="120px" src="https://static.wixstatic.com/media/49d33f_0499eef5ff18438592f4543cca97352f~mv2.png">
									<div class="hs51">VENTO<font color="#CCCCCC" >DE DEUS</font></div>

						</div>
						<!-- Logo -->
			</div>
			
	</div> 
<div>

	<ul id="botoesMenu"class="Menu">
          <button class= "botao"style='width:100%;' onclick="(window.location= '../inicio')">Início</button><br>
          <button class= "botao" style='width:100%;' onclick="(window.location= '../blog')">Blog</button><br>
          <button class= "botao" style='width:100%;' onclick="(window.location= 'Facebook')">Redes Sociais</button><br>
          <button class= "botao" style='width:100%;'>Ajuda ao necessitado (Em breve)</button><br>
		  <button class= "botao" style='width:100%;' >Podcast (Em breve)</button><br>
		  <button class= "botao" style='width:100%;' onclick="(window.location= 'sobre')">Sobre</button><br>
        </ul>


	 
	 </div>
	<button  id="botaoMenu" style= "cursor:pointer; position: absolute;top: 25px;   left: 80%; border-radius:5px; background: black; width: 60px; height: 50px; border: 1px solid #FF7700;">
			
			<hr/ style="width: 50%; border-color: #FF7700; ">	
			<hr/ style="width: 50%; border-color: #FF7700; ">
	</button>
	<button  id="botaoMenuX" style= "visibility:hidden; cursor:pointer; position: absolute;top: 25px;   left: 80%; border-radius:5px; background: black; width: 60px; height: 50px; border: 1px solid #FF7700; ">
	<div>
			<hr/ style="position:absolute; left:13px; top:8px;  transform: rotate(45deg);width: 50%; border-color: #FF7700; ">	
			<hr/ style="position:absolute; left:13px; top:8px;  transform: rotate(135deg);width: 50%; border-color: #FF7700; ">
			</div>
	</button>
	
<script>

function id(el) {
  return document.getElementById(el);
}


//var datttt = document.getElementById('dataDaPublicacao').value;    
    
//document.getElementById('datTexto').value =document.getElementById('dataDaPublicacao').value;

//id('dataDaPublicacao').addEventListener('onchange',function () {


var today = new Date();// document.getElementById('dataDaPublicacao').value;// new Date();
var dy = today.getDate();
var mt = today.getMonth()+1;
var yr = today.getFullYear();
var hr = today.getTime();

//if(mt === 1) {mt = "Janeiro"};
//if(mt === 2) {mt = "Fevereiro"};
//if(mt === 3) {mt = "Março"};
//if(mt === 4) {mt = "Abril"};
//if(mt === 5) {mt = "Maio"};
//if(mt === 6) {mt = "Junho"};
//if(mt === 7) {mt = "Julho"};
//if(mt === 8) {mt = "Agosto"};
//if(mt === 9) {mt = "Setembro"};
//if(mt === 10) {mt = "Outubro"};
//if(mt === 11) {mt = "Novembro"};
//if(mt === 12) {mt = "Dezembro"};


//document.getElementById("dataDoComentario").value =;// dy +" de "+ mt +" de "+ yr ;
//document.getElementById('dataDoComentario').value= dy+" de "+mt+" de "+yr ; <-?php echo date('d/m/Y') ;?>




function visualizarfuncao() {
    
setInterval(function () {
//wixLocation.to("/paginas")
    
    
document.getElementById("btnvisi").click();


}, 1000);
    
}

function sess() {
//document.getElementById("curtida").click();
}

window.onload = function() {
//    document.getElementById("curti").checked = true;
//     document.getElementById("checkBox").checked;
 document.getElementById("visi").value = document.getElementById("visu").value;
 document.getElementById("titu").value = document.getElementById("titulo").value;
  document.getElementById("upcurtida").value = <?php echo $_SESSION['curtidaa']?>;
//var  $varivisu = document.getElementById("visu").value;
var $contvisu = document.getElementById("titu").value;

function mostrarbotao() {
    
document.getElementById("comentariosubmit").focus();

}
}

$(document).ready(function(){
 //   var fdf = document.getElementById("upcurtida").value;
 $("#curti").click(function() {
//document.getElementById("upcurtida").value = fdf + "1";
 
     document.getElementById("divcurtir").click();
     
  

   });
   
   
   
   ///////
   
   ////
   <?php
   
   $ctd_id1 = $_SESSION['curtidab'];
  $ctd3 = $_SESSION['curtidaa'];
if ($_SESSION[$ctd_id1] != 'curtida') { ?>
document.getElementById("curti").checked = true;
<?php } elseif
($_SESSION[$ctd_id1] == 'curtida') { ?>
document.getElementById("curti").checked = false;

<?php } else { ?>
<?php

} ?>
 	
});

$(document).ready(function(){
   $("#textocoment").click(function() {

     document.getElementById("comentar").click();
     
     
   });
   
});

//id('textocoment').addEventListener('onchange',function () {
//document.getElementById("botoesMenu").style = 'visibility: visible; ';
//})

id('botaoMenu').addEventListener('click',function () {
document.getElementById("botoesMenu").style = 'visibility: visible; ';
document.getElementById("botaoMenuX").style.visibility = 'visible';	
document.getElementById("botaoMenu").style.visibility = 'hidden';	
})
id('botaoMenuX').addEventListener('click',function () {
document.getElementById("botoesMenu").style = 'visibility: hidden;';	
document.getElementById("botaoMenuX").style.visibility = 'hidden';	
document.getElementById("botaoMenu").style.visibility = 'visible';	
})

function myFunction() {
    

setInterval(function () {
    

 //   document.getElementById("curtida").click();
    
//window.onload = function() {
//   <meta http-equiv="refresh" content="5">
//}

}, 1000);


//setInterval(function(){ 
  //          n=n+1;
    //        document.getElementById("meuReload").innerHTML = "alterando a outra div"+n; },
            
//2000);
     
}

function up() {
    
    //$up = mysql_query("UPDATE Post SET  curtidas='$_POST[curtidas]'+ '1' WHERE titulo='$_POST[titulo]'");
}



window.onload = function() {
 function makeid() {

  var texto = "";
  var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

  for (var i = 0; i < 32; i++)
    texto += possible.charAt(Math.floor(Math.random() * possible.length));

document.getElementById("idcomentarios").value = texto;

  return texto;
}

console.log(makeid());
}

</script>
<div id="comentar" name="comentar" onCLick="window.open('https://www.ventodedeus.com.br/post/ajaxlogin.php','_blank');"></div>
<div id="divcurtir" name="divcurtir" onCLick="window.open('https://www.ventodedeus.com.br/post/ajaxcurtida.php','_blank');"></div>





<!-- FIM DO MENU -->
<br>
	<br><br><br>
	<!-- LOGIN -->
	<?php
	
$gerarid = md5();
	
//	 $sessaocurtida   = $_SESSION[$_GET['id']; 
 $usuario   = $_SESSION['usuarioNome']; 
 ?>
 
        <div  align=  "center" style= "color: white; font-family:Arial;" >Olá <strong><?php echo $usuario;?></strong> - Hoje é: <?php echo date('d/m/Y') ;?>

<button id="logout" class= "botao" style='width:100px; text-align:center; ' onclick="(window.location= '/login/sair.php')">Sair</button>
<button id="login"class= "botao" style='width:100px; text-align:center;' onclick="(window.location= '../login')">Login</button>
<br>  
        </div><!--Bem Vindo-->
  <?php 
 
 if ($usuario != "" ) { ?>
 
  <script>
 document.getElementById("logout").style.visibility = 'visible';
 document.getElementById("login").style.visibility = 'hidden';
   </script>
   <?php } else{ ?>
  
  <script>
 document.getElementById("logout").style.visibility = 'hidden';
 document.getElementById("login").style.visibility = 'visible';
   </script>
 <?php } ?>
 
<!-- LOGIN -->
<div align= "center">
<p style="font-family: Nimbus Sans; text-align: center;width:90%;color:white; font-size:23pt">POST</p><br>
			<div class= "postagem">
			<hr/ class= "hra">
											<div align= "left"> 
											<button id= "Todos" class= "botao">Todos</button>
											<button id= "Categoria1" class= "botao">Lei</button>
											<button id= "Categoria2" class= "botao"> Obediência</button>
											<button id= "Categoria3" class= "botao">Festas do nosso Deus</button>
											</div>
	
	

<?php

//$up = mysql_query("UPDATE Post SET   curtidas= '$_POST[curtidas]'+ '1' WHERE id='$_POST[id]'");

$sql="SELECT * from Post where id = '".$_GET["id"]."' ";
$rs=mysql_query($sql,$conn) or die(mysql_error());
$result=mysql_fetch_array($rs);


 $lin= $result["dataDaPublicacao"];
setlocale(LC_ALL, "pt_BR", "pt_BR.iso-8859-1", "pt_BR.utf-8", "portuguese");
date_default_timezone_set("America/Sao_Paulo");
$olddata = $lin;
$data = str_replace('/', '-', $olddata);
 $data1 =  strftime("%d de %B de %Y", strtotime($data));
//$sessao = $_SESSION[$_GET['id']+'qtde'] ;
echo '<div class= "textoPostagem"><br><br>
						<h1 style=" white-space: pre-wrap;font-family: Comic Sans Ms; text-align: center;width:90%;">'.$result["titulo"].'</h1>
						
               
               
               '.$data1.' por '.$result["autor"].'<br><br><br>
               <img align= "center"style="margin-left:10px; "width="175"  src="'.$result["imagens"].'">
				<br>
				
						<br>
						<h4 style=" white-space: pre-wrap;font-family: Comic Sans Ms; text-align: center;width:90%;">'.$result["subtitulo"] .'</h4>
					<br>
						<p   style=" white-space: pre-wrap;font-family: Comic Sans Ms; text-align: justify;width:90%;">'. 
						$result["texto"] .'</p>
					<br>
 <div align="left"style="margin-left:5%;"> 
  <form id="formulario "name="formulario" method="post">
 	
  <div align="right" style="float:right;margin-right:4%;">'.$result["visualizacao"].' visualizações  </div>

 			<span class="tw-heart-box">
 <div id="upcurtida" align="left" style="margin-left:8%;float:left;">'.$result["curtidas"].'</div>
 
 <input   id="curti" name="curti" type="checkbox" value="on" onclick="" class="confirmacoes">
  

  
  
  
  
  <span style="margin-top:-35%;" class="tw-heart"> </span>
   <input  style="visibility:hidden;"type="submit" id="curtida">
 <input style="visibility:hidden;" type="text" id="titulo" name="titulo"value="'.$result["titulo"].'">

 <input  style="visibility:hidden;" id="curtidas" type="number"name="curtidas" value="'.$result["curtidas"].'">

 <input style="visibility:hidden;" type="text" id="id" name="id"value="'.$result["id"].'">
			
  </form>
  
  </div>
  <br><br>	</div>
						
	
 <input  style="visibility:hidden;" id="visu" type="number"name="visu" value="'.$result["visualizacao"].'">
				';

?>
		    
<div id="meuReload" style="margin-left:-30%;" class="field">
<?php
$now = new DateTime();
$datetime = $now->format('Y-m-d H:i:s');
 
?>
<form action="insertComentarios.php" method="post">
<input type="hidden" name="idDoPost"  id="idDoPost" value="<?php echo $result["id"]?>">
<input type="hidden" name="autorComentario"  id="autorComentario" value="<?php echo $usuario;?>">
<input type="hidden" name="idcomentarios"  id="idcomentarios" value="">
<input type="hidden" style="visibility:;"name="dataDoComentario"  id="dataDoComentario" value="<?php echo $datetime;?>">

<input onchange="mostrarbotao()"type="text" id="textocoment" name="textocoment" placeholder="Faça seu comentário*" >
 
 <?php 
 
 if ($_SESSION['usuarioNiveisAcessoId'] == "1") { ?>
  
<input class="botao" style="visibility:;margin-left:2%;position:absolute;"type="submit" id="comentariosubmit">
   <?php } else { ?>
  
  
 <?php } ?>

 <?php 
 
 if ($_SESSION['usuarioNiveisAcessoId'] == "2") { ?>
  
<input class="botao" style="visibility:;margin-left:2%;position:absolute;"type="submit" id="comentariosubmit">
   <?php } else { ?>
  
  
 <?php } ?>

 <?php 
 
 if ($_SESSION['usuarioNiveisAcessoId'] == "3") { ?>
  
<input class="botao" style="visibility:;margin-left:2%;position:absolute;"type="submit" id="comentariosubmit">
   <?php } else { ?>
  
  
 <?php } ?>



 
   </form>
  <script> 
  
<?php

$ctd_id = $result['id'];
$ctd = $result['curtidas'];
$_SESSION['curtidaa'] = $ctd;
$_SESSION['curtidab'] = $ctd_id;
     
     
 ?>


<?php //} else {
?>

 <?php// } ?>
      
      
</script>
   


    
</div>  
					
<div class= "textoPostagem" style="width:70%; margin-left:-18%; ">

<?php
$sql1="SELECT * from Comentarios WHERE idDoPost= '".$_GET["id"]."' ORDER BY  dataDoComentario DESC";
$rs1=mysql_query($sql1,$conn) or die(mysql_error());
$result1=mysql_fetch_array($rs1);

$total = mysql_num_rows($rs1);

				
	
	
		if($total > 0 ) { 
		    
		// inicia o loop que vai mostrar todos os dados
		do {
		    
	for($i=0; $i<1; $i++);
	{
	   
echo '<div align="left">
<p   style="font-size:9pt; white-space: pre-wrap;font-family: Comic Sans Ms; text-align: left;margin-left:0%; width:70%;">'.$result1["autor"] .' - '.$result1["dataDoComentario"] .'</p>
<p   style="margin-top:-2%; white-space: pre-wrap;font-family: Comic Sans Ms; text-align: left;margin-left:5%; width:70%;">'.$result1["comentario"] .'</p>

<hr>
</div>';
	
              
		}	
         
         
                            
              ?>
              
              

<?php
	
// finaliza o loop que vai mostrar os dados
		}while($result1=mysql_fetch_array($rs1));
	// fim do if
	
	
	}
?>
       
  </div>			<br><br>	</div>
		
			<br>
		
		
		<hr/ class= "hrb">
					
			</div>
<br>
</div>
<script>


</script>

<script>
//------checked curtidas
//-----ll$(document).ready(function(){
    
//-----ll    <-?php
  //-----ll  $ctd = $result['curtidas'];
 //-----ll   if ($_SESSION[$_GET['id']] != 'curtido') { 
     
////// mysql_query("UPDATE Post SET  curtidas='$ctd'+ '1' WHERE id='$_GET[id]'");
//-----ll?>
//-----lldocument.getElementById("curti").checked = false;

//-----ll<-?php } else {
//-----ll?>
//document.getElementById("curti").checked = true;
//-----ll <-?php } ?>
 
 
//   });
   
//-----ll//-----ll});

//------checked curtidas final

//$(document).ready(function(){
</script>



 <?php 
 //visualização
 $varivisu = $result['visualizacao'];
 if ($_SESSION['visualizacao'] != $_GET['id']) { 
     
 $_SESSION['visualizacao'] = $_GET['id'];
 mysql_query("UPDATE Post SET  visualizacao='$varivisu'+ '1' WHERE id='$_GET[id]'");

?>

<?php } else {// $_SESSION["visu"] = "1";
?>

 <?php } ?>
 
<hr/ class= hra>



</body>
		<div align= "center">
					<div style="font-family: Comic Sans Ms; background: #605E5E; text-align: center; width:50%; margin-left: center;">
							<p style= "color:white">© 2020 de Leandro Donizete e Natália Domingues.<br>

oventodedeus@gmail.com</p>
					</div>
		</div>
</html>