<!DOCTYPE html>
<html>
<?

    session_start();
	if($_SESSION['usuarioNiveisAcessoId'] == "1"){
			//	header("Location: ../adm");
			}elseif($_SESSION['usuarioNiveisAcessoId'] == "2"){
			//	header("Location: ../adm");
			}else{
				header("Location: ../login");
			}
			?>

	<head>
	
	
<link rel="49d33f_0499eef5ff18438592f4543cca97352f~mv2 icon" href="https://static.wixstatic.com/media/49d33f_0499eef5ff18438592f4543cca97352f~mv2.png" >

<link href='https://fonts.googleapis.com/css?family=Anton' rel='stylesheet'>

<meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" media="screen" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" />
    <link rel="stylesheet" type="text/css" media="screen" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" />
  
    <meta charset="utf-8"/>


		<title>
Escrevendo
		</title>

<style>

  .miniatura {
    height: 75px;
    border: 1px solid #000;
    margin: 10px 5px 0 0;
  }
.hs51 { 

    font-family: 'Anton';
	font-size: 22px;
	color:#FF7700;
	position: absolute;
	text-decoration: underline;
	 top: -15px;
   left: center;
   
} 

.hs52 {
    font-family: 'Anton';
	font-size: 28px;
	color: #CCCCCC;
	position: absolute;
   top: 20px;
   left: 65px;
}

.hs53 {

width: 100%
	position: absolute;
   top: 14px;
   left: 130px;
}

.h3 { 
font-family: Anton; 
font-size: 14px; 
font-style: normal; 
font-variant: normal; 
font-weight: 700; 
line-height: 15.4px; } 
color:FF7700;
.p { 
font-family: Anton; 
font-size: 14px; 
font-style: normal; 
font-variant: normal; 
font-weight: 400; 
line-height: 20px; } 

.blockquote { 
font-family: Anton; 
font-size: 21px; 
font-style: normal; 
font-variant: normal; 
font-weight: 400; 
line-height: 30px; 
} 
.pre { 
font-family: Anton; 
font-size: 13px; 
font-style: normal; 
font-variant: normal; 
font-weight: 400; 
line-height: 18.5714px; }


#esquerda3400 {


	width: 111px;
	position: fixed;
	left: 900px;
	margin-top:-100px;
	}

.circulo{
border-radius:50%;
-moz-border-radius:50%;
-webkit-border-radius:50%;

background:#FF5500;
color:white;
width:111px;
height:111px;
line-height:100px;
vertical-align:middle;
text-align:center;
font-size:30px;


}

body {
            background-color: black;
        }
.hra{
  border-color:#FF7700;

  box-sizing:border-box;
  width:100%;

  border-bottom: 5px solid #FF7700;
}
.hrb{
  border-color:#cccccc;

  box-sizing:border-box;
  width:100%;

  border-bottom: 5px solid #cccccc;
}
.Menu {
right:20%;
	position: absolute;
   top: 25px;
   
     background-color: black;
     border: 1px solid #FF7700;
   }
#botoesMenu {
	
	visibility: hidden;
	
   
   }
.botao {

	font-weight: bold;
	margin-left: 02px;
	font-family: Nimbus Sans;
    background-color: transparent;
    outline: 0;
    text-align: left;
    border-radius: 10px;
	border: 0px;
   font-size: 13pt;
   margin: 2px;
   color: white;
}

.botao:hover {
  color: white;
  background-color:#FF5500;
  transition: color 0.2s 0.10s ease;
  transition: background-color 0.2s 0.05s ease;
  cursor: pointer;
  
  }
  
  
.jsjpfylp {
	background-color: #FF7700;
}
.postagem {


	width: 70%;
	left: center;
    
    background-color: #2F2E2E;
    box-shadow: 0 0 08px;
    margin: 10px;
	
}

.textoPostagem {

	width:97%;
	left: center;
    height: 9%;
    background-color: white;
    box-shadow: 0 0 08px;
    margin: 10px;
}
</style>
</head>

<body>
    
  <script type="text/javascript" src="ajax.js"></script>

<!-- MENU -->

<hr/ class= "hrb" style= "margin-top: 2px;">
<hr/ class= "hra" style= "margin-top: -16px;">
	
	<div>
			<div class="hs53">
				<img style="margin-top:-1%;" width="270px" src="https://static.wixstatic.com/media/49d33f_1b99852a9f63498084abf3dba864f78a~mv2.jpg">
						<!-- Logo -->
						<div class="hs52">
									<img width="120px" src="https://static.wixstatic.com/media/49d33f_0499eef5ff18438592f4543cca97352f~mv2.png">
									<div class="hs51">VENTO<font color="#CCCCCC" >DE DEUS</font></div>

						</div>
						<!-- Logo -->
			</div>
			
	</div> 
<div>

	<ul id="botoesMenu"class="Menu">
          <button class= "botao"style='width:100%;' onclick="(window.location= '../inicio')">Início</button><br>
          <button class= "botao" style='width:100%;' onclick="(window.location= '../blog')">Blog</button><br>
          <button class= "botao" style='width:100%;' onclick="(window.location= '../Facebook')">Redes Sociais</button><br>
          <button class= "botao" style='width:100%;'>Ajuda ao necessitado (Em breve)</button><br>
		  <button class= "botao" style='width:100%;' >Podcast (Em breve)</button><br>
		  <button class= "botao" style='width:100%;' onclick="(window.location= '../sobre')">Sobre</button><br>
    	  <button class= "botao" style='width:100%;' onclick="(window.location= '../adm')">Área administrativa</button><br>
          <button class= "botao" style='width:100%;' onclick="(window.location= '../post-Escrever')">Criar Post</button><br>
    	  
     
     
     </ul>


	 
	 </div>
	<button  id="botaoMenu" style= "cursor:pointer; position: absolute;top: 25px;   left: 80%; border-radius:5px; background: black; width: 60px; height: 50px; border: 1px solid #FF7700;">
			
			<hr/ style="width: 50%; border-color: #FF7700; ">	
			<hr/ style="width: 50%; border-color: #FF7700; ">
	</button>
	<button  id="botaoMenuX" style= "visibility:hidden; cursor:pointer; position: absolute;top: 25px;   left: 80%; border-radius:5px; background: black; width: 60px; height: 50px; border: 1px solid #FF7700; ">
		<div>
			<hr/ style="position:absolute; left:13px; top:8px;  transform: rotate(45deg);width: 50%; border-color: #FF7700; ">	
			<hr/ style="position:absolute; left:13px; top:8px;  transform: rotate(135deg);width: 50%; border-color: #FF7700; ">
			</div>
	</button>
	
<script>


function id(el) {
  return document.getElementById(el);
}






	
function id(el) {
  return document.getElementById(el);
}


id('botaoMenu').addEventListener('click',function () {
document.getElementById("botoesMenu").style = 'visibility: visible; ';
document.getElementById("botaoMenuX").style.visibility = 'visible';	
document.getElementById("botaoMenu").style.visibility = 'hidden';	
})
id('botaoMenuX').addEventListener('click',function () {
document.getElementById("botoesMenu").style = 'visibility: hidden;';	
document.getElementById("botaoMenuX").style.visibility = 'hidden';	
document.getElementById("botaoMenu").style.visibility = 'visible';	
})


</script>
<!-- FIM DO MENU -->

	<br><br><br>
	<!-- LOGIN -->
	<?php
 $usuario   = $_SESSION['usuarioNome']; 
 ?>
 
        <div  align=  "center" style= "color: white; font-family:Arial;margin-left:15%;" >Olá <strong><?php echo $usuario;?></strong> - Hoje é: <?php echo date('d/m/Y') ;?>

<button id="logout" class= "botao" style='width:100px; text-align:center; ' onclick="(window.location= '/login/sair.php')">Sair</button>
<button id="login"class= "botao" style='width:100px; text-align:center;' onclick="(window.location= '../login')">Login</button>
<br>  
        </div><!--Bem Vindo-->
  <?php 
 
 if ($usuario != "" ) { ?>
 
  <script>
 document.getElementById("logout").style.visibility = 'visible';
 document.getElementById("login").style.visibility = 'hidden';
   </script>
   <?php } else{ ?>
  
  <script>
 document.getElementById("logout").style.visibility = 'hidden';
 document.getElementById("login").style.visibility = 'visible';
   </script>
 <?php } ?>
 
<!-- LOGIN -->
<script>

window.onload = function() {

var datttt = document.getElementById('dataDaPublicacao').value;    
    
//document.getElementById('datTexto').value =document.getElementById('dataDaPublicacao').value;

//id('dataDaPublicacao').addEventListener('onchange',function () {
var today = new Date();// document.getElementById('dataDaPublicacao').value;// new Date();
var dy = today.getDate();
var mt = today.getMonth()+1;
var yr = today.getFullYear();
var hr = today.getTime();

if(mt === 1) {mt = "Janeiro"};
if(mt === 2) {mt = "Fevereiro"};
if(mt === 3) {mt = "Março"};
if(mt === 4) {mt = "Abril"};
if(mt === 5) {mt = "Maio"};
if(mt === 6) {mt = "Junho"};
if(mt === 7) {mt = "Julho"};
if(mt === 8) {mt = "Agosto"};
if(mt === 9) {mt = "Setembro"};
if(mt === 10) {mt = "Outubro"};
if(mt === 11) {mt = "Novembro"};
if(mt === 12) {mt = "Dezembro"};
document.getElementById('dataDaPublicacao').value= dy+" de "+mt+" de "+yr +hr ;
document.getElementById('dataTexto').value= dy+" de "+mt+" de "+yr ;
//})
function id(el) {
  return document.getElementById( el );
}

var wrapper = document.querySelector('.wrapper');
var textarea = document.querySelector('.textarea');


textarea.addEventListener('input', function () {
  wrapper.innerHTML = this.value;

})

 function makeid() {

  var texto = "";
  var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

  for (var i = 0; i < 32; i++)
    texto += possible.charAt(Math.floor(Math.random() * possible.length));

document.getElementById("id").value = texto;

  return texto;
}
console.log(makeid());
}

</script>
<br><br><br><br>
	
	

<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
			
<div align= "center">
<p id="eee" style="font-family: Nimbus Sans; text-align: center;width:90%;color:white; font-size:23pt">ESCREVENDO UM POST</p><br>
			<div class= "postagem">
			<hr/ class= "hra">
											<div align= "left"> 
											<button id= "Todos" class= "botao" style="">Todos</button>
											<button id= "Categoria1" class= "botao">Lei</button>
											<button id= "Categoria2" class= "botao"> Obediência</button>
											<button id= "Categoria3" class= "botao">Festas do nosso Deus</button>
											</div>
<?php
$gerarid = md5();
?>					

<form name= "postagem" action="insert.php" method="post">
   
   
 	
						<div class= "textoPostagem"><br>
	
						
						
						<textarea class="textarea"  name= "titulo" id="titulo" style="font-family: Comic Sans Ms; text-align: left;width:90%; " placeholder="Título"></textarea>
						
						
						<br>
		<textarea placeholder="Subtítulo" class="textarea"  name="subtitulo"  id= "subtitulo"style="font-family: Comic Sans Ms; text-align: left;width:90%;"></textarea>
						

						<textarea placeholder= "Post" class="textarea" name= "texto" id="texto"style="font-family: Comic Sans Ms; text-align: left;width:90%; height: 1000px"></textarea><br>




<input class ="botao" type="button" value="Categoria 1" onClick="document.postagem.ans.value+='Categoria 1'+', '">

	

<input class="esquerda" type="textfield" name="ans" value="">


				<div>



			</div>
   <br><br>
   
   
<input name="imagens" type="file" multiple id="imagens">

<div class="galeria"></div>	
<br><br>
<input name="dataTexto" id="dataTexto" value=""type="text" style= "visibility:hidden ;" >


Data da publicação: <input type='datetime-local' id='dataDaPublicacao' name='dataDaPublicacao' value='<?php echo date( 'd-m-Y H:i:s') ;?>'requeired>





	Autor: <input name="autor" id="autor" value="<?php echo $usuario;?>"type="text" style= "visibility: ;" >
<br>
    <input type="checkbox" id="rascunho" name="rascunho"
         checked>
  <label for="rascunho">Salvar como rascunho</label>
	<input class="botao" style= "color:black;" id="enviar"type="submit">
<br><br>
</div>
		
		
		
				
	<input name="NomeDoBlog" id="NomeDoBlog" value="VentoDeDeus" type="text" style= "visibility: hidden ;" >
	
<input type="hidden" name="id"  id="id" value="">
</form>
		
			
		
<hr/ class= "hrb">
			</div>
<br>
</div>

  	
  	
<script>

//}

$(function() {
// Pré-visualização de várias imagens no navegador
var visualizacaoImagens = function(input, lugarParaInserirVisualizacaoDeImagem) {

    if (input.files) {
        var quantImagens = input.files.length;

        for (i = 0; i < quantImagens; i++) {
            var reader = new FileReader();

            reader.onload = function(event) {
                $($.parseHTML('<img class="miniatura">')).attr('src', event.target.result).appendTo(lugarParaInserirVisualizacaoDeImagem);
            }

            reader.readAsDataURL(input.files[i]);
        }
    }

};

$('#imagens').on('change', function() {
    visualizacaoImagens(this, 'div.galeria');
});
});
  </script>
  



<hr/ class= hra>



</body>
		<div align= "center">
					<div style="font-family: Comic Sans Ms; background: #605E5E; text-align: center; width:60%; margin-left: center;">
							<p style= "color:white">© 2020 de Leandro Donizete e Natália Domingues.<br>

oventodedeus@gmail.com</p>
					</div>
		</div>
</html>