
<?php


    session_start();
function testeOnclick() {


//include ('valida.php');
//include ('conecta.php');
	if($_SESSION['usuarioNiveisAcessoId'] == "1"){
	echo "<script>window.close()</script>";


	//	header("Location: ../adm");
			}elseif($_SESSION['usuarioNiveisAcessoId'] == "2"){
			    echo "<script>window.close()</script>";
	//	header("Location: ../adm");
			}elseif($_SESSION['usuarioNiveisAcessoId'] == "3"){
	echo "<script>window.close()</script>";
	//	header("Location: ../adm");
			}else{
				header("Location: ../logininscrito.php");
			}

}

testeOnclick();


?>