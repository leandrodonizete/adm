<?php
//chama o arquivo de conexão com o bd
include('conectaPost.php');
 
 
$up = mysql_query("UPDATE Post SET  visualizacao='$_POST[visi]'+ '1' WHERE titulo='$_POST[titu]'");
 
if(mysql_affected_rows() > 0){
//   "window.location='../inicio'";
  echo"Sucesso: Atualizado corretamente!   ";
}else{
  echo "Aviso: Não foi atualizado!   ";
}
 
mysql_close($conexao);
					?>