<?php
	$servidor = "mysql669.umbler.com:41890";
	$usuario = "leandrodomingues";
	$senha = "a36825700";
	$dbname = "ventodedeus";
	
	//Criar a conexao
	$conn = mysqli_connect($servidor, $usuario, $senha, $dbname);
	
	if(!$conn){
		die("Falha na conexao: " . mysqli_connect_error());
	}else{
		//echo "Conexao realizada com sucesso";
	}	
	
?>